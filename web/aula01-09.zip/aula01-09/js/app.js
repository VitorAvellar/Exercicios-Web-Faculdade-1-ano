//tipos de comentarios 
//simples: //
//limnhas compostas: /**/ 

//console do navegador - para exibir, passar informações, verificação de erros- console.log('conteudo')
//PONTO E VIRGULA EM JS É OPCIONAL
console.log('Olá, eu sou o console')
console.log('Aprendendo JavaScript')

/*navegador é o responsavel pela interpretação do JS
Faz a leitura de linha por linha e faz a exibição
se tiver erro ele para a execução e 
vc pode ver o erro do console */

//js é case sensitiv
console.log('O js é uma linguagem de programação')

//váriaveis não tem tipo - JS é uma linguagem não tipada.
//não precisamos definir o tipo de dado que a variavel recebera.
//Tipagem dinamica - tipagem automatica  feita pela linguagem ==> pelo valor atribuido
//para criar variavel use:
//let nomeVariavel = valor inicial
//nomeVariavel é padrão camelcase
//variavel deve ser autoexplicativa
let userName = 'Vitor Avellar'
let userEmail = 'vitor10sa@hotmail.com'
let userID = 4521
let userLogin = true

console.log(userName)
console.log(userEmail)
console.log(userID)
console.log(userLogin)



//Verificar o tipo que foi atrubuido typeof
console.log(userName, typeof userName)
console.log(userEmail, typeof userEmail)
console.log(userID, typeof userID)
console.log(userLogin, typeof userLogin)

//criar uma variavel e não iniciar - como ficara o tipo?

let namepet = 'Cristiano Ronaldo e Luna'
console.log(namepet)

//quando vc muda p contudo da variavel passando um outro tipo o JSautomaticamente refaz a tipagem para aqela variavel
userID = 'vdsa'
console.log(userID, typeof userID)

userID = 4521
console.log(userID, typeof userID)

//concatenação =  variavel + String
//NÃO FAZEMOS EM JS 
console.log('Nome do usario: ' + userName + 'email do usuario:' + userEmail)


//template String / literal String = USAR SEMPRE(DEVEMOS)
//iniciar e finalixar com sinal de crase `aqui dentro fica a String`
//podemos chamr as variaveis usandoplaceholders = ${variavel} - isso dentro das crases

console.log(`Nome do usuario: ${userName} 
                               id do Usuario: ${userID}
                               Email:${userEmail}`)

//Forma antiga de declarar variavel = nunca usar essa Forma       
// var : voce pode declarar a variavel quantas vezes quoser  === errado 

var bookName = 'Codigo Limpo'
console.log(`nomedo livro: ${bookName}`)

console.log(`nomedo livro: ${bookName}`)


//constantes = valores que não mudam.

const dataNascimento = '20/02'
console.log(`data do nascimento: ${dataNascimento}`)

//gera um erro pois uma const bão pode ter valor alterado

//gera um erro pois uma constante precisa ser inicializado
//const.agepet
//console.log(agepet)

let agePet = null
console.log(agePet)


//array
const numbers = [1,2,3,4,5,6,7,8,9]
console.log(numbers)
console.log(typeof numbers)





