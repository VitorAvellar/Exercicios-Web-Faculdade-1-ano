// tipos de comentários:
// linha simples  //
// linha composta /* */

// console do navegador - para exibir , passar informações, verificaçao de erros - console.log('conteúdo')
// ponto e vírgula em JS é opcional
console.log('Olá, eu sou o console');
console.log('Aprendendo JavaScript');

// Navegador é o responsável pela interpretação do JS 
// Faz a leitura de linha por linha e faz a exibição
// Se tiver erro ele para a execução 
// Vc pode ver o erro no console

// JS é case sensitive
console.log('O JS é uma linguagem de programação'); 

// variáveis não têm tipo - JS é uma linguagem Não Tipada
// não precisamos definir o tipo de dado que a variável receberá.
// Tipagem dinâmica - tipagem automática feita pela linguagem ==> pelo valor atribuído
// para criar variáveis use:
// let nomeVariável = valor inicial;
// nomeVariável é padrão camelCase
// variável deve ser autoexplicativa 
// userNameApp

let userName = 'Israel Marques';
let userEmail = 'profisrael.copi@fiap.com.br';
let userId = 7894;
let userLogin = true;

console.log(userName);
console.log(userEmail);
console.log(userId);
console.log(userLogin);

//verificar o tipo que foi atribuído typeof
console.log(userName, typeof userName);
console.log(userEmail, typeof userEmail);
console.log(userId, typeof(userId));
console.log(userLogin, typeof(userLogin));

// Criar uma variável e não iniciar - como ficará o tipo?????
let namePet;
console.log(namePet);
console.log(typeof(namePet));


// quando vc muda o conteúdo da variável passando um outro tipo, o JS automaticamente refaz a tipagem para aquela
// variável
userId = 'mnbgh';
console.log(userId, typeof(userId));

userId = 7894;
console.log(userId, typeof(userId));

// concatenação = variável + string
//NÃO FAZEMOS EM JS  - NÃO DEVEMOS FAZER EM JS
console.log('Nome do usuário:' +userName + ' email do usuário: '+ userEmail);

// Template String / Literal String = USAR SEMPRE (DEVEMOS)
// Iniciar e finalizar com sinal de crase `aqui dentro fica a string`
// podemos chamar as variáveis usando placeholders = ${variável} - isso dentro das crases

console.log(`Nome do usuário: ${userName} 
                 Id do Usuário: ${userId}
                 Email: ${userEmail}`);

// Forma antiga de declarar variável = NUNCA USAR ESSA FORMA
//var você pode redeclarar suas variáveis quantas vezes quiser === ERRADO
// o var deixa a variável como GLOBAL

var  bookName = 'Código Limpo';
console.log(`nome do livro: ${bookName}`);

for(var i = 0; i<=10; i++) {
    console.log(`Valor de i = ${i} = ${userName}`);
}

console.log(`Valor final do i = ${i}`);
i+=100;
console.log(`Valor final do i = ${i}`);


// Constantes = valores que não mudam
const dataNascimento = '02/12';
console.log(`Data do Nascimento: ${dataNascimento}`);

// gera um erro pois uma const não pode ter ser valor alterado
// dataNascimento = '01/11';

// Gera um erro pois uma constante precisa ser inicializada
// const agePet;
// console.log(agePet);

let agePet = null;
console.log(agePet, typeof(agePet));

// array
const numbers = [3,4,7,8,9,12,34,22,1,0];
console.log(numbers);
console.log(typeof numbers);
