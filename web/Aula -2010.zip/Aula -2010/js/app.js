// pegar o tbody no html e passar para o JS
const tbody = document.querySelector('tbody');

// pegar o formulário
// escutador de eventos - submit 
// criar uma função e passar o evento para dentro dessa função
// cancelar o evento para que as informações digitadas no formulário, não sejam apagadas

document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();

    // recuperar os campos colocar as informações em um array
    const campos = [
        document.querySelector('#usuario'),
        document.querySelector('#email'),
        document.querySelector('#dataCadastro'),
        document.querySelector('#tipoConta')
    ];
    // console.log(campos);

    // criando uma tr
    const tr = document.createElement('tr');

    // criar um for para percorrer o array 
    // para cada índice do array uma função será criada
    // criar uma td
    // colocar o value do campo no text da td(inserir o conteúdo na td)
    // colocar a td na tr

    campos.forEach(campo =>{
        // console.log(campo.value);
        const td = document.createElement('td');
        td.textContent = campo.value;
        tr.appendChild(td);
    })
    
    // for(let i=0; i<campos.length; i++){
    //     const td = document.createElement('td');
    //     td.textContent = campos[i].value;
    //     tr.appendChild(td);        
    // }

    // vinculando a tr no tbody
    tbody.appendChild(tr);

    this.reset();   
})