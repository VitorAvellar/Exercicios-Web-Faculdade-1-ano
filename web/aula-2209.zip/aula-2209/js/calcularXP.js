// pegando o botão no HTML
const btnCalcular = document.querySelector('#btnCalcular');

btnCalcular.addEventListener('click', function(){
    
    // pegar todo mundo que tem a class heroi - TEREMOS UM ARRAY
    const herois = document.querySelectorAll('.heroi');
    console.log(herois);
    
    // fazer um for para percorrer os heróis
    for(let i = 0; i < herois.length; i++){
        let velocidade = Number(herois[i].querySelector('.velocidade').textContent);
        let agilidade = Number(herois[i].querySelector('.agilidade').textContent);
        let forca = Number(herois[i].querySelector('.forca').textContent);
        let xpFinal = (velocidade + agilidade + forca)/3;
        herois[i].querySelector('.xp').textContent = xpFinal.toFixed(1);

        if(xpFinal < 70){
             herois[i].style.backgroundColor = "#900";
             herois[i].style.color = "#fff";
            herois[i].classList.add('bg-danger', 'text-light');
        }
    }


});

